export const API_ROOT_URL = "http://localhost:8080"

export const SOCKET_ROOT_URL = "ws://localhost:8080/ws"

// TODO: ストレージを作ったらそっちに以降
export const DEFAULT_IMAGE_PATH = "https://64.media.tumblr.com/4ae6990e4ad2ee1b714ebb6c7b7f5a00/e8988a531b4aeabd-37/s128x128u_c1/d5e4a743b16c3e7bbe5de98ef185c49061722b54.jpg"